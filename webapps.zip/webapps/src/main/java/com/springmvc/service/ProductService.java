package com.springmvc.service;

import java.util.List;

import com.springmvc.model.Product;

public interface ProductService {

	public boolean addProduct(Product product) ;
	public Product getProduct(String productCode);
	public List<Product> getProducts();
	public List<Product> getProducts(String category);
	
	public boolean updateProduct(Product product) ;
	public boolean deleteProduct(String productCode);
}
