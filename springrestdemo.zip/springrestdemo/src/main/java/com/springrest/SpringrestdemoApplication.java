package com.springrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestdemoApplication.class, args);
	}

}
