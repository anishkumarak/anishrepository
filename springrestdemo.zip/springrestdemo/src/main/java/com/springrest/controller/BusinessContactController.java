package com.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.model.BusinessContact;
import com.springrest.service.ContactService;

@RestController
public class BusinessContactController {

	@Autowired
	ContactService contactService;
	
	
	@PostMapping("/BusinessContact/")
	public ResponseEntity<Void> addContact(@RequestBody BusinessContact contact) {
		
		boolean result = contactService.addContact(contact);
		if(result) {
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value="/BusinessContact/{contactId}", produces=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<BusinessContact> getContact(@PathVariable("contactId") String contactId) {
		
		BusinessContact contact = contactService.getContact(contactId);
		if(contact!=null) {
			return new ResponseEntity<BusinessContact>(contact, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping(value="/SearchContact/{organization}", produces=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<List<BusinessContact>> getContacts(@PathVariable("organization") String organization) {
		
		List<BusinessContact> contactList = contactService.getContacts(organization);
		return new ResponseEntity<List<BusinessContact>>(contactList, HttpStatus.OK);
	}
	
	@DeleteMapping("/BusinessContact/{contactId}")
	public ResponseEntity<Void> deleteContact(@PathVariable("contactId") String contactId) {
		
		boolean result = contactService.removeContact(contactId);
		if(result) {
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
	}

	
}
