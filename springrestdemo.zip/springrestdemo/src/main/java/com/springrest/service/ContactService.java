package com.springrest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.springrest.model.BusinessContact;

@Service
public class ContactService {

	static List<BusinessContact> contacts = new ArrayList<BusinessContact>();
	
	public boolean addContact(BusinessContact contact) {
	
		return contacts.add(contact);
	}
	
	public BusinessContact getContact(String contactId) {
		
		for(BusinessContact contact : contacts) {
			if(contact.getContactId().equals(contactId)) {
				return contact;
			}
		}
		return null;
	}
	
	public boolean removeContact(String contactId) {
	
		boolean status = false;
		for(BusinessContact contact : contacts) {
			if(contact.getContactId().equals(contactId)) {
				contacts.remove(contact);
				status = true;
				break;
			}
		}
		return status;
	}
	
	
	public List<BusinessContact> getContacts(String organization) {
		
		List<BusinessContact> contactList = new ArrayList<BusinessContact>();
		
		for(BusinessContact contact : contacts) {
			if(contact.getOrganization().equals(organization)) {
				contactList.add(contact);
			}
		}
		return contactList;
	}
}
