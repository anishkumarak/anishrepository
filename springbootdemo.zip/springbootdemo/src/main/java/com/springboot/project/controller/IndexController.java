package com.springboot.project.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.project.model.Employee;

@Controller
public class IndexController {

	@RequestMapping(value="/", method=RequestMethod.GET)
	public String showHomePage() {   //HANDLER METHOD
		return "index";   //control string
	}
	
	
	@GetMapping("/showEmp")
	public ModelAndView showEmp() {
		
		Employee emp = new Employee(101, "Ramesh", "Manager", 50000.00, "Male", new Date());
		
		ModelAndView mv = new ModelAndView("emp", "employee", emp);
		return mv;
	}		
}

