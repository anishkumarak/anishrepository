package com.springboot.project.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.project.model.BusinessContact;
import com.springboot.project.model.Product;

@Controller
public class ContactController {

	@GetMapping("/contactForm")
	public ModelAndView showContactForm() {
		
		ModelAndView mv = new ModelAndView("contact","contact", new BusinessContact());
		return mv;
	}
	
	@PostMapping(value="/addContact")
	@ResponseBody
	public String addContact(@ModelAttribute("contact")BusinessContact contact) {
		
		//consune the webservice.
		RestTemplate template = new RestTemplate();
		
		Void result = template.postForObject("http://localhost:8080/BusinessContact/", contact, Void.class);
		//template.postForEntity(url, request, responseType)
		return "Contact Added successfully";
	}
	
	
	@GetMapping("/findContactByOrganization")
	public ModelAndView findContactByOrganization() {
		
		RestTemplate template = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity <String> entity = new HttpEntity<String>(headers);

				
		ResponseEntity<List<BusinessContact>> result =
				template.exchange("http://localhost:8080/SearchContact/IBM", 
								  HttpMethod.GET, 
								  entity, 
								  new ParameterizedTypeReference<List<BusinessContact>>(){});

		List<BusinessContact> contacts = result.getBody();
		System.out.println(contacts.toString());
		ModelAndView mv = new ModelAndView("organization","organization",contacts);
		//result.getStatusCode()
		return mv;
	}
}
