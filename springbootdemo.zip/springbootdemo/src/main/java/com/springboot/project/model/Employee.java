package com.springboot.project.model;

import java.util.Date;

public class Employee {

	private int empno; 
	private String name;
	private String designation;
	private double salary;
	private String gender;
	private Date joindate;
	
	public Employee(){}

	public Employee(int empno, String name, String designation, double salary, String gender, Date joindate) {
		super();
		this.empno = empno;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.gender = gender;
		this.joindate = joindate;
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getJoindate() {
		return joindate;
	}

	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}

	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", name=" + name + ", designation=" + designation + ", salary=" + salary
				+ ", gender=" + gender + ", joindate=" + joindate + "]";
	}
	
}
