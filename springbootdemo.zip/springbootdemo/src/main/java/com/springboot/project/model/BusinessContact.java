package com.springboot.project.model;

public class BusinessContact {

	private String contactId;
	private String contactName;
	private String designation;
	private String organization;
	private String email;
	private String contactNo;
	private String address;
	
	public BusinessContact() {}

	public BusinessContact(String contactId, String contactName, String designation, String organization, String email,
			String contactNo, String address) {
		super();
		this.contactId = contactId;
		this.contactName = contactName;
		this.designation = designation;
		this.organization = organization;
		this.email = email;
		this.contactNo = contactNo;
		this.address = address;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "BusinessContact [contactId=" + contactId + ", contactName=" + contactName + ", designation="
				+ designation + ", organization=" + organization + ", email=" + email + ", contactNo=" + contactNo
				+ ", address=" + address + "]";
	}
	
	
}
