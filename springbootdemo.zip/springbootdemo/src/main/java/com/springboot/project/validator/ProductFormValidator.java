package com.springboot.project.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.springboot.project.model.Product;

@Component
public class ProductFormValidator implements Validator{

	@Override
	public boolean supports(Class<?> cls) {
		return Product.class.equals(cls);
	}

	@Override
	public void validate(Object target, Errors errors) {

		Product prod = (Product) target;
		
		ValidationUtils.rejectIfEmpty(errors, "productCode", "productForm.productCode.empty");
		ValidationUtils.rejectIfEmpty(errors, "productDescription", "productForm.productDescription.empty");
		ValidationUtils.rejectIfEmpty(errors, "unitPrice", "productForm.unitPrice.empty");
		ValidationUtils.rejectIfEmpty(errors, "qoh", "productForm.qoh.empty");
		
		if(prod.getUnitPrice() <0)
			errors.reject("unitPrice", "productForm.unitPrice.negative");
	
		if(prod.getQoh() <0)
			errors.reject("qoh", "productForm.qoh.negative");

	}
	
	

}
